const button = document.querySelector(".btn");
const image =document.querySelector(".img");
const url = "https://some-random-api.ml/img/bird";

async function fetchHandler() {
    try {
        const response = await fetch(url);
        const data = await response.json();
        console.log(response);
        image.src = data.file;
    } catch(error){
        console.log(error);
    }
}
button.addEventListener("click", () => {
    fetchHandler();
})